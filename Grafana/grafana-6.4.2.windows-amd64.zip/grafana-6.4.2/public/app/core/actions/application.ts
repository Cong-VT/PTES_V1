import { noPayloadActionCreatorFactory } from 'app/core/redux';

export const toggleLogActions = noPayloadActionCreatorFactory('TOGGLE_LOG_ACTIONS').create();
